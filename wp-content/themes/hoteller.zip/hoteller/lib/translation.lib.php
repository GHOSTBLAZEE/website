<?php
load_theme_textdomain( 'hoteller', get_template_directory().'/languages' );
?>