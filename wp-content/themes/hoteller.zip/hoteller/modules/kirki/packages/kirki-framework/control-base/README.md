# control-base

This package serves as a base for other controls.

By itself the `\Kirki\Control\Base` doesn't do anything. It is simply an object that all other Kirki controls should extend to avoid code duplication.